﻿namespace Library
{
    partial class Manage_AddMembers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manage_AddMembers));
            this.DocumentTypeBox = new System.Windows.Forms.ComboBox();
            this.AltPhoneNumber = new System.Windows.Forms.Label();
            this.EmailAddress = new System.Windows.Forms.Label();
            this.PhoneNumber = new System.Windows.Forms.Label();
            this.DocumentType = new System.Windows.Forms.Label();
            this.DocumentNo = new System.Windows.Forms.Label();
            this.PostalCode = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CustomerName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AltPhoneNumberBox = new System.Windows.Forms.TextBox();
            this.Confirm = new System.Windows.Forms.Button();
            this.EmailAddressBox = new System.Windows.Forms.TextBox();
            this.PhoneNumberBox = new System.Windows.Forms.TextBox();
            this.DocumentNoBox = new System.Windows.Forms.TextBox();
            this.PostalCodeBox = new System.Windows.Forms.TextBox();
            this.AddressBox = new System.Windows.Forms.TextBox();
            this.AgeBox = new System.Windows.Forms.TextBox();
            this.CustomerNameBox = new System.Windows.Forms.TextBox();
            this.CustomerIDBox = new System.Windows.Forms.TextBox();
            this.Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DocumentTypeBox
            // 
            this.DocumentTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DocumentTypeBox.FormattingEnabled = true;
            this.DocumentTypeBox.Location = new System.Drawing.Point(733, 73);
            this.DocumentTypeBox.Name = "DocumentTypeBox";
            this.DocumentTypeBox.Size = new System.Drawing.Size(208, 23);
            this.DocumentTypeBox.TabIndex = 56;
            // 
            // AltPhoneNumber
            // 
            this.AltPhoneNumber.AutoSize = true;
            this.AltPhoneNumber.Location = new System.Drawing.Point(600, 273);
            this.AltPhoneNumber.Name = "AltPhoneNumber";
            this.AltPhoneNumber.Size = new System.Drawing.Size(119, 15);
            this.AltPhoneNumber.TabIndex = 55;
            this.AltPhoneNumber.Text = "AltPhoneNumber";
            // 
            // EmailAddress
            // 
            this.EmailAddress.AutoSize = true;
            this.EmailAddress.Location = new System.Drawing.Point(616, 209);
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.Size = new System.Drawing.Size(103, 15);
            this.EmailAddress.TabIndex = 54;
            this.EmailAddress.Text = "EmailAddress";
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.AutoSize = true;
            this.PhoneNumber.Location = new System.Drawing.Point(624, 142);
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.Size = new System.Drawing.Size(95, 15);
            this.PhoneNumber.TabIndex = 53;
            this.PhoneNumber.Text = "PhoneNumber";
            // 
            // DocumentType
            // 
            this.DocumentType.AutoSize = true;
            this.DocumentType.Location = new System.Drawing.Point(592, 76);
            this.DocumentType.Name = "DocumentType";
            this.DocumentType.Size = new System.Drawing.Size(127, 15);
            this.DocumentType.TabIndex = 52;
            this.DocumentType.Text = "DocumentType(*)";
            // 
            // DocumentNo
            // 
            this.DocumentNo.AutoSize = true;
            this.DocumentNo.Location = new System.Drawing.Point(156, 404);
            this.DocumentNo.Name = "DocumentNo";
            this.DocumentNo.Size = new System.Drawing.Size(111, 15);
            this.DocumentNo.TabIndex = 51;
            this.DocumentNo.Text = "DocumentNo(*)";
            // 
            // PostalCode
            // 
            this.PostalCode.AutoSize = true;
            this.PostalCode.Location = new System.Drawing.Point(180, 338);
            this.PostalCode.Name = "PostalCode";
            this.PostalCode.Size = new System.Drawing.Size(87, 15);
            this.PostalCode.TabIndex = 50;
            this.PostalCode.Text = "PostalCode";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(180, 273);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(87, 15);
            this.Address.TabIndex = 49;
            this.Address.Text = "Address(*)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(212, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 15);
            this.label3.TabIndex = 48;
            this.label3.Text = "Age(*)";
            // 
            // CustomerName
            // 
            this.CustomerName.AutoSize = true;
            this.CustomerName.Location = new System.Drawing.Point(140, 142);
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.Size = new System.Drawing.Size(127, 15);
            this.CustomerName.TabIndex = 47;
            this.CustomerName.Text = "CustomerName(*)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(180, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 15);
            this.label1.TabIndex = 46;
            this.label1.Text = "CustomerID";
            // 
            // AltPhoneNumberBox
            // 
            this.AltPhoneNumberBox.Location = new System.Drawing.Point(733, 270);
            this.AltPhoneNumberBox.Name = "AltPhoneNumberBox";
            this.AltPhoneNumberBox.Size = new System.Drawing.Size(208, 25);
            this.AltPhoneNumberBox.TabIndex = 45;
            // 
            // Confirm
            // 
            this.Confirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Confirm.Location = new System.Drawing.Point(627, 424);
            this.Confirm.Name = "Confirm";
            this.Confirm.Size = new System.Drawing.Size(169, 36);
            this.Confirm.TabIndex = 43;
            this.Confirm.Text = "Confirm";
            this.Confirm.UseVisualStyleBackColor = true;
            this.Confirm.Click += new System.EventHandler(this.Confirm_Click_1);
            // 
            // EmailAddressBox
            // 
            this.EmailAddressBox.Location = new System.Drawing.Point(733, 199);
            this.EmailAddressBox.Name = "EmailAddressBox";
            this.EmailAddressBox.Size = new System.Drawing.Size(208, 25);
            this.EmailAddressBox.TabIndex = 42;
            // 
            // PhoneNumberBox
            // 
            this.PhoneNumberBox.Location = new System.Drawing.Point(733, 139);
            this.PhoneNumberBox.Name = "PhoneNumberBox";
            this.PhoneNumberBox.Size = new System.Drawing.Size(208, 25);
            this.PhoneNumberBox.TabIndex = 41;
            // 
            // DocumentNoBox
            // 
            this.DocumentNoBox.Location = new System.Drawing.Point(273, 401);
            this.DocumentNoBox.Name = "DocumentNoBox";
            this.DocumentNoBox.Size = new System.Drawing.Size(208, 25);
            this.DocumentNoBox.TabIndex = 40;
            // 
            // PostalCodeBox
            // 
            this.PostalCodeBox.Location = new System.Drawing.Point(273, 335);
            this.PostalCodeBox.Name = "PostalCodeBox";
            this.PostalCodeBox.Size = new System.Drawing.Size(208, 25);
            this.PostalCodeBox.TabIndex = 39;
            // 
            // AddressBox
            // 
            this.AddressBox.Location = new System.Drawing.Point(273, 270);
            this.AddressBox.Name = "AddressBox";
            this.AddressBox.Size = new System.Drawing.Size(208, 25);
            this.AddressBox.TabIndex = 38;
            // 
            // AgeBox
            // 
            this.AgeBox.Location = new System.Drawing.Point(273, 206);
            this.AgeBox.Name = "AgeBox";
            this.AgeBox.Size = new System.Drawing.Size(208, 25);
            this.AgeBox.TabIndex = 37;
            // 
            // CustomerNameBox
            // 
            this.CustomerNameBox.Location = new System.Drawing.Point(273, 139);
            this.CustomerNameBox.Name = "CustomerNameBox";
            this.CustomerNameBox.Size = new System.Drawing.Size(208, 25);
            this.CustomerNameBox.TabIndex = 36;
            // 
            // CustomerIDBox
            // 
            this.CustomerIDBox.Location = new System.Drawing.Point(273, 71);
            this.CustomerIDBox.Name = "CustomerIDBox";
            this.CustomerIDBox.ReadOnly = true;
            this.CustomerIDBox.Size = new System.Drawing.Size(208, 25);
            this.CustomerIDBox.TabIndex = 35;
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(841, 424);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(169, 36);
            this.Cancel.TabIndex = 57;
            this.Cancel.Text = "Cancel";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Manage_AddMembers
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1082, 523);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.DocumentTypeBox);
            this.Controls.Add(this.AltPhoneNumber);
            this.Controls.Add(this.EmailAddress);
            this.Controls.Add(this.PhoneNumber);
            this.Controls.Add(this.DocumentType);
            this.Controls.Add(this.DocumentNo);
            this.Controls.Add(this.PostalCode);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CustomerName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AltPhoneNumberBox);
            this.Controls.Add(this.Confirm);
            this.Controls.Add(this.EmailAddressBox);
            this.Controls.Add(this.PhoneNumberBox);
            this.Controls.Add(this.DocumentNoBox);
            this.Controls.Add(this.PostalCodeBox);
            this.Controls.Add(this.AddressBox);
            this.Controls.Add(this.AgeBox);
            this.Controls.Add(this.CustomerNameBox);
            this.Controls.Add(this.CustomerIDBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Manage_AddMembers";
            this.Text = "AddMembers";
            this.Load += new System.EventHandler(this.AddMembers_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox DocumentTypeBox;
        private System.Windows.Forms.Label AltPhoneNumber;
        private System.Windows.Forms.Label EmailAddress;
        private System.Windows.Forms.Label PhoneNumber;
        private System.Windows.Forms.Label DocumentType;
        private System.Windows.Forms.Label DocumentNo;
        private System.Windows.Forms.Label PostalCode;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label CustomerName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox AltPhoneNumberBox;
        private System.Windows.Forms.TextBox EmailAddressBox;
        private System.Windows.Forms.TextBox PhoneNumberBox;
        private System.Windows.Forms.TextBox DocumentNoBox;
        private System.Windows.Forms.TextBox PostalCodeBox;
        private System.Windows.Forms.TextBox AddressBox;
        private System.Windows.Forms.TextBox AgeBox;
        private System.Windows.Forms.TextBox CustomerNameBox;
        private System.Windows.Forms.TextBox CustomerIDBox;
        private System.Windows.Forms.Button Confirm;
        public System.Windows.Forms.Button Cancel;
    }
}